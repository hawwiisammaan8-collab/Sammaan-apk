package com.sammaan.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

private val Navy = Color(0xFF101D32)
private val Navy2 = Color(0xFF182943)
private val Gold = Color(0xFFE0B85C)
private val Cream = Color(0xFFF5F0E5)

data class Story(
    val id: String = "",
    val title: String = "",
    val category: String = "Jireenya",
    val body: String = "",
    val author: String = "SAMMAAN"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { SammaanApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SammaanApp() {
    var stories by remember { mutableStateOf(listOf(
        Story("sample1", "Jireenya keessatti abdii hin kutatin", "Jireenya",
            "Imalli jireenyaa yeroo hunda salphaa miti. Garuu obsaa, barumsa fi abdii qabaachuun tarkaanfii itti aanu fudhachuuf nama gargaara."),
        Story("sample2", "Jaalalli dhugaan maal fakkaata?", "Jaalala",
            "Jaalalli dhugaan kabaja, amanamummaa, dhaggeeffachuu fi waliif yaaduu irratti ijaarama.")
    )) }
    var selected by remember { mutableStateOf("Hunda") }
    var selectedStory by remember { mutableStateOf<Story?>(null) }
    var showLogin by remember { mutableStateOf(false) }
    var showPublish by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Jireenya") }
    var body by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Seenaa fakkeenyaa agarsiifamaa jiru. Firebase yoo walqabsiifte seenaawwan addunyaa guutuuf ni tamsa'u.") }
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }

    LaunchedEffect(Unit) {
        db.collection("stories").orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error == null && snapshot != null && !snapshot.isEmpty) {
                    stories = snapshot.documents.map { d ->
                        Story(d.id, d.getString("title") ?: "",
                            d.getString("category") ?: "Jireenya",
                            d.getString("body") ?: "", d.getString("author") ?: "SAMMAAN")
                    }
                    status = "Seenaawwan interneetii irraa fe'aman."
                }
            }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Navy, surface = Navy2,
        onPrimary = Navy, onBackground = Cream, onSurface = Cream
    )) {
        Scaffold(containerColor = Navy, topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("SAMMAAN", color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                        Text("SEENAALEE FI YAADANNOO", color = Cream.copy(alpha = .72f), fontSize = 10.sp, letterSpacing = 1.sp)
                    }
                },
                actions = {
                    TextButton(onClick = { showLogin = true }) {
                        Text(if (auth.currentUser == null) "ADMIN" else "MAXXANSI", color = Gold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
            )
        }) { padding ->
            if (selectedStory != null) {
                Column(Modifier.padding(padding).fillMaxSize().padding(20.dp)) {
                    Text("←  DUUBATII", color = Gold, modifier = Modifier.clickable { selectedStory = null }.padding(bottom = 20.dp))
                    Text(selectedStory!!.category.uppercase(), color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(selectedStory!!.title, color = Cream, fontSize = 27.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 14.dp))
                    Text(selectedStory!!.body, color = Cream.copy(alpha = .9f), fontSize = 17.sp, lineHeight = 27.sp)
                    Spacer(Modifier.height(24.dp))
                    Text("— ${selectedStory!!.author}", color = Gold, fontWeight = FontWeight.SemiBold)
                }
            } else {
                LazyColumn(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
                    item {
                        Spacer(Modifier.height(12.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Navy2), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(22.dp)) {
                                Text("BAGA SAMMAAN APP", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                Text("Seenaa dubbisi.\nYaada haaraa argadhu.", color = Cream, fontSize = 26.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp, modifier = Modifier.padding(top = 10.dp))
                                Text("Jireenya • Jaalala • Yaadannoo", color = Cream.copy(alpha = .7f), modifier = Modifier.padding(top = 10.dp))
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        Text("GOSA SEENAA", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Hunda", "Jireenya", "Jaalala", "Gaddaa").forEach { item ->
                                FilterChip(selected = selected == item, onClick = { selected = item }, label = { Text(item) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = Navy))
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("SEENAA HAARAA", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                    }
                    val visible = stories.filter { selected == "Hunda" || it.category == selected }
                    items(visible) { story ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { selectedStory = story },
                            colors = CardDefaults.cardColors(containerColor = Navy2),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (story.category == "Jaalala") Icons.Default.Favorite else Icons.Default.MenuBook,
                                    contentDescription = null, tint = Gold, modifier = Modifier.size(30.dp))
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(story.category.uppercase(), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(story.title, color = Cream, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                    Text(story.body, color = Cream.copy(alpha = .65f), maxLines = 2, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                    item {
                        Spacer(Modifier.height(12.dp))
                        Text(status, color = Cream.copy(alpha = .55f), fontSize = 11.sp)
                        Spacer(Modifier.height(30.dp))
                    }
                }
            }
        }
    }

    if (showLogin) {
        AlertDialog(
            onDismissRequest = { showLogin = false },
            title = { Text("Seensa Admin") },
            text = {
                Column {
                    OutlinedTextField(email, { email = it }, label = { Text("Email Admin") })
                    OutlinedTextField(password, { password = it }, label = { Text("Password") })
                    if (loginError.isNotBlank()) Text(loginError, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    auth.signInWithEmailAndPassword(email.trim(), password)
                        .addOnSuccessListener { showLogin = false; showPublish = true; loginError = "" }
                        .addOnFailureListener { loginError = "Seensa hin milkoofne. Email fi password ilaali." }
                }) { Text("SEENI") }
            },
            dismissButton = { TextButton(onClick = { showLogin = false }) { Text("Cufii") }
            }
        )
    }

    if (showPublish) {
        AlertDialog(
            onDismissRequest = { showPublish = false },
            title = { Text("Seenaa haaraa maxxansi") },
            text = {
                Column {
                    OutlinedTextField(title, { title = it }, label = { Text("Mata-duree") })
                    Spacer(Modifier.height(8.dp))
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }) { Text("Gosa: $category") }
                        DropdownMenu(expanded, { expanded = false }) {
                            listOf("Jireenya", "Jaalala", "Gaddaa", "Walaloo", "Gorsa").forEach {
                                DropdownMenuItem(text = { Text(it) }, onClick = { category = it; expanded = false })
                            }
                        }
                    }
                    OutlinedTextField(body, { body = it }, label = { Text("Barreeffama seenaa") }, minLines = 5)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isNotBlank() && body.isNotBlank()) {
                        db.collection("stories").add(hashMapOf(
                            "title" to title.trim(), "category" to category,
                            "body" to body.trim(), "author" to "SAMMAAN",
                            "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                        )).addOnSuccessListener {
                            title = ""; body = ""; showPublish = false
                            status = "Seenaa kee maxxansite."
                        }.addOnFailureListener { status = "Maxxansuun hin milkoofne. Firebase fi hayyama ilaali." }
                    }
                }) { Text("MAXXANSI") }
            },
            dismissButton = { TextButton(onClick = { showPublish = false }) { Text("DHIISI") } }
        )
    }
}
